// Re-export the hook from ThemeContext for convenience
export { useTheme } from '../context/ThemeContext';