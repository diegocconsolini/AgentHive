// Re-export the hook from AuthContext for convenience
export { useAuth } from '../context/AuthContext';