import React from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';

export const AdminPage: React.FC = () => {
  return <AdminLayout />;
};