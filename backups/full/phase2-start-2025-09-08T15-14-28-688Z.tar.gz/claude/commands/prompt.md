---
allowed-tools: Bash, Read, Write, LS
---

# This is an ephemeral command. 

Some complex prompts (with numerous @ references) may fail if entered directly into the prompt input. 

If that happens, write your prompt here and type in `/prompt` in the prompt command.
