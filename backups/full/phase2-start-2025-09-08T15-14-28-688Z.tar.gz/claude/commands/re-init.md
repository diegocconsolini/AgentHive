---
allowed-tools: Bash, Read, Write, LS
---

# Enhance CLAUDE.md file

Please update CLAUDE.md with the rules from .claude/CLAUDE.md.

If CLAUDE.md does not exist, create it using the /init and include rules from .claude/CLAUDE.md.
