---
allowed-tools: Bash
---

Run `bash .claude/scripts/pm/prd-status.sh` using a sub-agent and show me the complete output.

- DO NOT truncate.
- DO NOT collapse.
- DO NOT abbreviate.
- Show ALL lines in full.
- DO NOT print any other comments.
